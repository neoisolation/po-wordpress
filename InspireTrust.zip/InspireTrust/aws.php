<?php

// An example of using php-webdriver.
// Do not forget to run composer install before. You must also have Selenium server started and listening on port 4444.

namespace Facebook\WebDriver;

use Facebook\WebDriver\Remote\DesiredCapabilities;
use Facebook\WebDriver\Remote\RemoteWebDriver;
use Facebook\WebDriver\Chrome\ChromeOptions;

require_once('vendor/autoload.php');

// This is where Selenium server 2/3 listens by default. For Selenium 4, Chromedriver or Geckodriver, use http://localhost:4444/

$host = 'http://104.248.53.7:4444/wd/hub';

$capabilities = DesiredCapabilities::chrome();
$options = new ChromeOptions();
$options->setExperimentalOption('excludeSwitches', ['enable-automation']);
$options->addArguments(array('--user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'));
$capabilities->setCapability(ChromeOptions::CAPABILITY, $options);
$capabilities->setCapability('enableVNC', true);
$capabilities->setVersion('80.0');

$driver = RemoteWebDriver::create($host, $capabilities);

$driver->manage()->window()->maximize();

// navigate to Selenium page on Wikipedia
$driver->get('https://console.aws.amazon.com/?nc2=h_m_mc');

$driver->findElement(WebDriverBy::classname("aws-signin-textfield"))->sendKeys("thuanycrepaldi0101@gmail.com");
$driver->findElement(WebDriverBy::id("next_button"))->click();

