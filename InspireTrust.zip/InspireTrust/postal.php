<?php 

## php postal.php -d "domain name" -i "ip address"
## php postal.php -d "domain name" -i "ip address" >> /dev/null 2>&1;
## php postal.php -d "$1" -i "$2" >> /dev/null 2>&1;
## rm -rf postal.php


$arguments = getopt("m:p:w:");
require_once('vendor/autoload.php');
$client = new Postal\Client('https://postal.neo-isolation.fr', 'ecygDVUdr8SO8HQ                                                                                         $

$mail = trim($arguments["m"]);
$domainpostal = trim($arguments["p"]);
$domainwordpress = trim($arguments["w"]);

$message = new Postal\SendMessage($client);
$message->to($mail);
$message->from('info@neo-isolation.fr');
$message->subject('Your server has been Installed Successfuly');
$message->plainBody("Server Setup: \n\r\n\r Your Mail server link " .$domainpostal." Has been Installed Successfuly. \n\r\n\r Your Wordpress link " .$domainwordpress. "$
$result = $message->send();
?>

