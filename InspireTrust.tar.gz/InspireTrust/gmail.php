<?php

// Do not forget to run composer install before. You must also have Selenium server started and listening on port 4444.

namespace Facebook\WebDriver;

use Facebook\WebDriver\Remote\DesiredCapabilities;
use Facebook\WebDriver\Remote\RemoteWebDriver;
use Facebook\WebDriver\Chrome\ChromeOptions;

require_once('vendor/autoload.php');

$arguments = getopt("h:f:s:");
           # h: Selenium Host
           # f: gmail file "youremail@gmail.com:password:recoveryemail"
           # s: Subject Line Focused
############ Usage: 
############ php gmail.php -h "1.2.3.4" -f "gmail.txt" -s "Subject Line"
############ Background Usage: 
############ nohup php gmail.php -h "1.2.3.4" -f "gmail.txt" -s "Subject Line"&;

$Subject = $arguments["s"];
$seeds = fopen($arguments["f"], "r");
$Selenoid = $arguments["h"];

// This is where Selenium server 2/3 listens by default. For Selenium 4, Chromedriver or Geckodriver, use http://localhost:4444/

function generateRandom($min = 1, $max = 120)
{
    if (function_exists('random_int')) :
        return random_int($min, $max); // more secure
    elseif (function_exists('mt_rand')) :
        return mt_rand($min, $max); // faster
    endif;
    return rand($min, $max); // old
}

while (!feof($seeds)) {
    $emailAccount = fgets($seeds);

    $emailAccount = explode(":", $emailAccount);
    $emailAddress = $emailAccount[0];
    $emailPassword = $emailAccount[1];
    $emailRecovery = $emailAccount[2];

    $host = 'http://' . $Selenoid . ':4444/wd/hub';
    $capabilities = DesiredCapabilities::chrome();
    $options = new ChromeOptions();
    $options->setExperimentalOption('excludeSwitches', ['enable-automation']);
    //$options->addArguments(array('--incognito'));
    $capabilities->setCapability(ChromeOptions::CAPABILITY, $options);
    $capabilities->setCapability('enableVNC', true);
    $capabilities->setVersion('80.0');

    $driver = RemoteWebDriver::create($host, $capabilities);

    $driver->manage()->window()->maximize();

    echo "##################################### \n";
    echo $emailAddress . " - Session Started! \n";

    // navigate to Selenium page
    $driver->get('https://stackoverflow.com/users/login');

    sleep(generateRandom(10, 20));
    $driver->findElement(WebDriverBy::className('s-btn__google'))->click();
    sleep(generateRandom(10, 20));

    $human_verify = $driver->findElements(WebDriverBy::id("identifierId"));
    if (count($human_verify) > 0) {
        $driver->findElement(WebDriverBy::id("identifierId"))->sendKeys($emailAddress);
        $driver->findElement(WebDriverBy::id("identifierNext"))->click();
        sleep(generateRandom(10, 15));
        $password_verification = $driver->findElements(WebDriverBy::name("password"));
        if (count($password_verification) > 0) {
            $driver->findElement(WebDriverBy::name("password"))->sendKeys($emailPassword);
            $driver->findElement(WebDriverBy::id("passwordNext"))->click();
        }
    } else {
        echo $emailAddress . " - This email account can't be accessed - Bot Detection :( \n";
        echo $emailAddress . " - Session Ended! \n";
        sleep(generateRandom(50, 59));
        continue;
    }

    sleep(generateRandom(5, 10));

    $confirm_recovery_email_1 = $driver->findElements(WebDriverBy::xpath("/html/body/div[1]/div[1]/div[2]/div/div[2]/div/div/div[2]/div/div[1]/div/form/span/section/div/div/div/ul/li[1]/div/div[2]"));
    $confirm_recovery_email_4 = $driver->findElements(WebDriverBy::xpath("/html/body/div[1]/div[1]/div[2]/div/div[2]/div/div/div[2]/div/div[1]/div/form/span/section/div/div/div/ul/li[4]/div/div[2]"));

    // If verification is present, Confirm Recovery Email
    if (count($confirm_recovery_email_4) > 0) {
        try {
            $driver->findElement(WebDriverBy::xpath("/html/body/div[1]/div[1]/div[2]/div/div[2]/div/div/div[2]/div/div[1]/div/form/span/section/div/div/div/ul/li[4]/div/div[2]"))->click();
            sleep(generateRandom(5, 10));
            $driver->findElement(WebDriverBy::id("knowledge-preregistered-email-response"))->sendKeys($emailRecovery);
            $driver->findElement(WebDriverBy::xpath("/html/body/div[1]/div[1]/div[2]/div/div[2]/div/div/div[2]/div/div[2]/div/div[1]/div/div/span/span"))->click();
        } catch (\Throwable $th) {
            //throw $th;
        }
    } elseif (count($confirm_recovery_email_1) > 0) {
        try {
            $driver->findElement(WebDriverBy::xpath("/html/body/div[1]/div[1]/div[2]/div/div[2]/div/div/div[2]/div/div[1]/div/form/span/section/div/div/div/ul/li[1]/div/div[2]"))->click();
            sleep(generateRandom(5, 10));
            $driver->findElement(WebDriverBy::id("knowledge-preregistered-email-response"))->sendKeys($emailRecovery);
            $driver->findElement(WebDriverBy::xpath("/html/body/div[1]/div[1]/div[2]/div/div[2]/div/div/div[2]/div/div[2]/div/div[1]/div/div/span/span"))->click();
        } catch (\Throwable $th) {
            //throw $th;
        }
    }

    sleep(generateRandom(5, 10));
    $driver->get('https://gmail.com');

    // Check for https://www.google.com/gmail/about/ if True then define account as not working.

    $getCurrentURL = $driver->getCurrentURL();
    if (strpos($getCurrentURL, "gmail/about") !== false) {
        echo $emailAddress . " - This Email Account can't be recovered - Manuel Action Required \n";
        echo $emailAddress . " - Session Ended! \n";
        sleep(generateRandom(100, 120));
        continue;
    }

    sleep(generateRandom(10, 15));

    $driver->getKeyboard()->pressKey(WebDriverKeys::ESCAPE);
    sleep(generateRandom(5, 10));
    $driver->get('https://mail.google.com/mail/u/0/#spam');

    sleep(generateRandom(10, 15));

    $getCurrentURL = $driver->getCurrentURL();
    if (strpos($getCurrentURL, "#spam") !== false) {
        echo $emailAddress . " - Accessing SPAM Folder... \n";
    }
    $spam_confirm = $driver->findElements(WebDriverBy::xpath("/html/body/div[7]/div[3]/div/div[2]/div[1]/div[2]/div/div/div/div/div[2]/div/div[1]/div/div[2]/div[3]/div[2]/div/table/tbody/tr[1]/td[5]/div[2]/span/span"));
    // If Spam Folder Has Messages, "Mark as not Spam"
    $i = 50;
    $j = 1;
    for ($i = 1; $i < 50; $i++) {
        $spam_confirm = $driver->findElements(WebDriverBy::xpath("/html/body/div[7]/div[3]/div/div[2]/div[1]/div[2]/div/div/div/div/div[2]/div/div[1]/div/div/div[3]/div[2]/div/table/tbody/tr[" . $i . "]/td[6]/div/div/div/span/span[text()='" . $Subject . "']"));
        if (count($spam_confirm) > 0) {
            try {
                $driver->findElement(WebDriverBy::xpath("/html/body/div[7]/div[3]/div/div[2]/div[1]/div[2]/div/div/div/div/div[2]/div/div[1]/div/div/div[3]/div[2]/div/table/tbody/tr[" . $i . "]/td[6]/div/div/div/span/span[text()='" . $Subject . "']"))->click();
                sleep(generateRandom(5, 10));
                ## Mark as Starred
                $driver->findElement(WebDriverBy::xpath("/html/body/div[7]/div[3]/div/div[2]/div[1]/div[2]/div/div/div/div/div[2]/div/div[1]/div/div[3]/div/table/tr/td[1]/div[2]/div[2]/div/div[3]/div/div/div/div/div/div[1]/div[2]/div[1]/table/tbody/tr[1]/td[2]/div/div/span"))->click();
                echo $emailAddress . " - Message Number " . $j . " has been Starred \n";
                sleep(generateRandom(3, 5));
                ## Mark as Important
                $driver->findElement(WebDriverBy::xpath("/html/body/div[7]/div[3]/div/div[2]/div[1]/div[2]/div/div/div/div/div[2]/div/div[1]/div/div[3]/div/table/tr/td[1]/div[2]/div[1]/div[2]/div[1]/span/div/div[2]"))->click();
                echo $emailAddress . " - Message Number " . $j . " has been Marked as Important \n";
                sleep(generateRandom(3, 5));
                ## Report this message as not spam
                $driver->findElement(WebDriverBy::xpath('//button[text()="Report not spam"]'))->click();
                sleep(generateRandom(5, 10));
                echo $emailAddress . " - Message Number " . $j . " has been reported as not spam \n";
                $i--;
                $j++;
            } catch (\Throwable $th) {
                echo $emailAddress . " - There's an issue in the SPAM folder sequence \n";
            }
        }
    }

    ## Accessing the INBOX Folder
    $driver->get('https://mail.google.com/mail/u/0/#inbox');
    sleep(generateRandom(3, 5));

    $getCurrentURL = $driver->getCurrentURL();
    if (strpos($getCurrentURL, "#inbox") !== false) {
        echo $emailAddress . " - Accessing INBOX Folder... \n";
    }

    $i = 50;
    $j = 1;
    for ($i = 1; $i < 50; $i++) {
        $inbox_check = $driver->findElements(WebDriverBy::xpath("/html/body/div[7]/div[3]/div/div[2]/div[1]/div[2]/div/div/div/div/div[2]/div/div[1]/div/div[1]/div[7]/div/div[1]/div[3]/div/table/tbody/tr[" . $i . "]/td[6]/div/div/div/span/span[text()='" . $Subject . "']"));
        if (count($inbox_check) > 0) {
            try {
                # Access Message in the Inbox Folder
                $driver->findElement(WebDriverBy::xpath("/html/body/div[7]/div[3]/div/div[2]/div[1]/div[2]/div/div/div/div/div[2]/div/div[1]/div/div[1]/div[7]/div/div[1]/div[3]/div/table/tbody/tr[" . $i . "]/td[6]/div/div/div/span/span[text()='" . $Subject . "']"))->click();
                echo $emailAddress . " - Message Number " . $j . " has been Opened in the Inbox Folder Successfuly \n";
                sleep(generateRandom(5, 10));

                # Archive Message
                $driver->findElement(WebDriverBy::xpath("/html/body/div[7]/div[3]/div/div[2]/div[1]/div[2]/div/div/div/div/div[1]/div[3]/div[1]/div/div[2]/div[1]/div"))->click();
                echo $emailAddress . " - Message Number " . $j . " has been Archived \n";
                sleep(generateRandom(5, 10));
                $i--;
                $j++;
            } catch (\Throwable $th) {
                echo $emailAddress . " - There's an issue in the INBOX folder sequence \n";
            }
        }
    }

    ## Accessing Promotion if Exist
    sleep(generateRandom(3, 5));
    $Promotion = $driver->findElements(WebDriverBy::xpath("//div[text()='Promotions']"));

    if (count($Promotion) > 0) {
        try {
            echo $emailAddress . " - Accessing Promotion Folder... \n";
            $driver->findElement(WebDriverBy::xpath("//div[text()='Promotions']"))->click();
            sleep(generateRandom(5, 10));
            $i = 50;
            $j = 1;
            for ($i = 1; $i < 50; $i++) {
                $promotion_check = $driver->findElements(WebDriverBy::xpath("/html/body/div[7]/div[3]/div/div[2]/div[1]/div[2]/div/div/div/div/div[2]/div/div[1]/div/div/div[7]/div/div[3]/div[6]/div/table/tbody/tr[" . $i . "]/td[6]/div/div/div/span/span[text()='" . $Subject . "']"));
                if (count($promotion_check) > 0) {
                    try {
                        # Access Message in the Inbox Folder
                        $driver->findElement(WebDriverBy::xpath("/html/body/div[7]/div[3]/div/div[2]/div[1]/div[2]/div/div/div/div/div[2]/div/div[1]/div/div/div[7]/div/div[3]/div[6]/div/table/tbody/tr[" . $i . "]/td[6]/div/div/div/span/span[text()='" . $Subject . "']"))->click();
                        echo $emailAddress . " - Message Number " . $j . " has been Opened in the Promotion Folder Successfuly \n";
                        sleep(generateRandom(5, 10));

                        # Archive Message
                        $driver->findElement(WebDriverBy::xpath("/html/body/div[7]/div[3]/div/div[2]/div[1]/div[2]/div/div/div/div/div[1]/div[3]/div[1]/div/div[2]/div[1]/div"))->click();
                        echo $emailAddress . " - Message Number " . $j . " has been Archived \n";
                        sleep(generateRandom(5, 10));
                        $i--;
                        $j++;
                    } catch (\Throwable $th) {
                        echo $emailAddress . " - There's an issue in the Promotion folder sequence \n";
                    }
                }
            }
        } catch (\Throwable $th) {
            //throw $th;
        }
    }

    echo $emailAddress . " - Session Ended! \n";
    sleep(generateRandom(10, 15));
}
fclose($seeds);
